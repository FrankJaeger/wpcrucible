<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'impetsty_wpcr');

/** MySQL database username */
define('DB_USER', 'impetsty_wpcr');

/** MySQL database password */
define('DB_PASSWORD', 'wpcr-playground');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'W[C:XCk_sxcB(<P=*#H/Bb{j)~x/sH6I+9VQa()Hz*GZh+/Ez+?}$]W43-K%{nYv');
define('SECURE_AUTH_KEY',  'tpSb (gLt@x+ht*r|W{l+z&tygQ6ZTRl0.sBDHL&xZ$-#(&MS,co$8J{3_H %w/w');
define('LOGGED_IN_KEY',    'A4ahgoqrz)9K@dii.`iR?aW|Qx]bQxLSk4+ 7SiaDMOnlu,+z>pT41}+w>:bxEOD');
define('NONCE_KEY',        '|&|=|yed!7v5L|0eDu=G^Z-!Evh$,,XgvWFuuItzed+*KWFh-SUZ[ONFWA|+Z10j');
define('AUTH_SALT',        '!B*jh7p-hzVccm:jwj<Hli|UO^OU$:@8P-6~P_(PwpwEYvZ40+fGsdV6zN=Fk,3%');
define('SECURE_AUTH_SALT', 'Mcxf5C7&3Qpz,nj;(b+9!7BpU=pd{C3d;uL1zeZ.2Gr(/RG++F(@Xm0*7?UdQH4z');
define('LOGGED_IN_SALT',   '6eAk=vhsp1,*4*7-9nCBVa=-%)FMIXlAl(-WO.(NjWH`=85|(-u1zHJ=TAo,]6h%');
define('NONCE_SALT',       'EcS%4{Ed)D+Y)7qJ7~5P]d[|F^~,ZxZtC/>cIS+gs=Y7[#Vn:Qx+ ?ybl!08/@*3');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpcr_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
